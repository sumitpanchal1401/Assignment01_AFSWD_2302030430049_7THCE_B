
EduStream Mock Prototype
========================

Features implemented (mock/in-memory):
- Media gallery with video playback
- Dark mode (persisted via localStorage)
- JWT authentication (login)
- Shopping cart and checkout (in-memory)
- Real-time quiz validation (HTML5)
- Dashboard showing progress and cart summary

How to run:
1) Backend:
   cd backend
   npm install
   node server.js

2) Frontend:
   cd frontend
   npm install
   npm run dev

Demo credentials: student / password
