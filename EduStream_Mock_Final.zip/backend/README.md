Backend (mock):
1. npm install
2. node server.js
Runs on http://localhost:4000
Demo user: student / password
