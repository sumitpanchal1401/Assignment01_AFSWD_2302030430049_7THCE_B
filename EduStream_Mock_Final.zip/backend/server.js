const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const app = express();
app.use(cors());
app.use(bodyParser.json());

const SECRET = 'edustream_demo_secret_v1';

// Mock data
const courses = [
  { id: 'c1', title: 'Intro to JavaScript', description: 'Basics of JS', video: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4', price: 10 },
  { id: 'c2', title: 'HTML & CSS', description: 'Build web pages', video: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4', price: 8 }
];

const users = {
  'student': { password: 'password', progress: [], preferences: { theme: 'light' }, cart: [] }
};

// Helper auth
function generateToken(username){
  return jwt.sign({ username }, SECRET, { expiresIn: '6h' });
}

function auth(req, res, next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({ message: 'No token' });
  const parts = h.split(' ');
  if(parts.length !== 2) return res.status(401).json({ message: 'Bad token' });
  try{
    const decoded = jwt.verify(parts[1], SECRET);
    req.user = decoded.username;
    next();
  } catch(e){
    return res.status(401).json({ message: 'Invalid token' });
  }
}

// Public endpoint: courses
app.get('/api/courses', (req, res) => {
  res.json(courses);
});

// Auth: login (returns token)
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = users[username];
  if(!user || user.password !== password) return res.status(401).json({ message: 'Invalid credentials' });
  const token = generateToken(username);
  res.json({ token });
});

// Get cart
app.get('/api/cart', auth, (req, res) => {
  const u = req.user;
  res.json({ items: users[u].cart || [] });
});

// Add to cart
app.post('/api/cart', auth, (req, res) => {
  const u = req.user;
  const { courseId } = req.body;
  const course = courses.find(c => c.id === courseId);
  if(!course) return res.status(404).json({ message: 'Course not found' });
  users[u].cart.push(course);
  res.json({ ok: true, cart: users[u].cart });
});

// Checkout (mock)
app.post('/api/checkout', auth, (req, res) => {
  const u = req.user;
  const items = users[u].cart || [];
  items.forEach(i => {
    if(!users[u].progress.includes(i.title)) users[u].progress.push(i.title);
  });
  users[u].cart = [];
  res.json({ status: 'success', completed: users[u].progress });
});

// Progress
app.get('/api/progress', auth, (req, res) => {
  const u = req.user;
  res.json({ completed: users[u].progress || [] });
});

// Preferences update
app.post('/api/preferences', auth, (req, res) => {
  const u = req.user;
  const prefs = req.body;
  users[u].preferences = Object.assign(users[u].preferences || {}, prefs);
  res.json({ ok: true, preferences: users[u].preferences });
});

// Simple server
const PORT = 4000;
app.listen(PORT, () => console.log('EduStream mock backend running on', PORT));