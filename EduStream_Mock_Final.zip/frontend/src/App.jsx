import React, { useEffect, useState } from 'react';
import Login from './components/Login';
import Media from './components/Media';
import Dashboard from './components/Dashboard';
import Quiz from './components/Quiz';
import axios from 'axios';

export default function App(){
  const [token, setToken] = useState(()=> localStorage.getItem('edustream_token') || null);
  const [theme, setTheme] = useState(()=> localStorage.getItem('edustream_theme') || 'light');

  useEffect(()=>{
    document.body.style.background = theme === 'dark' ? '#121212' : '#fff';
    document.body.style.color = theme === 'dark' ? '#eee' : '#111';
    localStorage.setItem('edustream_theme', theme);
  }, [theme]);

  function handleLogin(t){
    setToken(t);
    localStorage.setItem('edustream_token', t);
  }
  function handleLogout(){
    setToken(null);
    localStorage.removeItem('edustream_token');
  }

  return (
    <div style={{maxWidth:1000, margin:'20px auto', padding:20}}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>EduStream (Mock)</h1>
        <div>
          <button onClick={()=>setTheme(theme==='dark'?'light':'dark')}>Toggle Dark</button>
          {token ? <button onClick={handleLogout} style={{marginLeft:10}}>Logout</button> : null}
        </div>
      </div>
      {!token ? <Login onLogin={handleLogin} /> :
        <>
          <Media token={token} />
          <Quiz />
          <Dashboard token={token} />
        </>
      }
    </div>
  )
}