import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function Dashboard({ token }){
  const [progress, setProgress] = useState([]);
  const [cart, setCart] = useState([]);
  useEffect(()=>{
    async function load(){
      try{
        const p = await axios.get('http://localhost:4000/api/progress', { headers:{ Authorization: 'Bearer '+token } });
        setProgress(p.data.completed || []);
        const c = await axios.get('http://localhost:4000/api/cart', { headers:{ Authorization: 'Bearer '+token } });
        setCart(c.data.items || []);
      }catch(e){ console.log(e); }
    }
    load();
  }, [token]);
  return (
    <div style={{marginTop:20}}>
      <h2>Dashboard & Analytics</h2>
      <div style={{display:'flex', gap:12}}>
        <div style={{flex:1, border:'1px solid #eee', padding:12}}>
          <h3>Progress</h3>
          <p>Completed: {progress.length}</p>
          <ul>{progress.map((p,i)=>(<li key={i}>{p}</li>))}</ul>
        </div>
        <div style={{flex:1, border:'1px solid #eee', padding:12}}>
          <h3>Cart</h3>
          <p>Items in cart: {cart.length}</p>
          <ul>{cart.map((c,i)=>(<li key={i}>{c.title}</li>))}</ul>
        </div>
      </div>
    </div>
  )
}