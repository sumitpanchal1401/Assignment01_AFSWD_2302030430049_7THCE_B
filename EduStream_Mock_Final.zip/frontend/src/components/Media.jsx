import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function Media({ token }){
  const [courses, setCourses] = useState([]);
  useEffect(()=>{ axios.get('http://localhost:4000/api/courses').then(r=>setCourses(r.data)); }, []);

  async function addToCart(id){
    try{
      await axios.post('http://localhost:4000/api/cart', { courseId: id }, { headers: { Authorization: 'Bearer '+token } });
      alert('Added to cart');
    }catch(e){ alert('Error'); }
  }

  return (
    <div style={{marginTop:20}}>
      <h2>Media Gallery</h2>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
        {courses.map(c=> (
          <div key={c.id} style={{border:'1px solid #ccc', padding:12}}>
            <h3>{c.title}</h3>
            <p>{c.description}</p>
            <video width="100%" controls src={c.video}></video>
            <div style={{marginTop:8}}><button onClick={()=>addToCart(c.id)}>Add to Cart (${'${c.price}'})</button></div>
          </div>
        ))}
      </div>
    </div>
  )
}