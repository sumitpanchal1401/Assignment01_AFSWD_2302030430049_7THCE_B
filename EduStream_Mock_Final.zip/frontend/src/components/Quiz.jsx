import React, { useRef, useState } from 'react';
export default function Quiz(){
  const formRef = useRef();
  const [msg, setMsg] = useState('');
  function submit(e){
    e.preventDefault();
    const f = formRef.current;
    if(!f.checkValidity()){ setMsg('Please fill required'); return; }
    const ans = f.elements['q1'].value;
    setMsg(ans==='B' ? 'Correct' : 'Incorrect');
  }
  return (
    <div style={{marginTop:20, border:'1px dashed #ccc', padding:12}}>
      <h2>Quick Quiz</h2>
      <form ref={formRef} onSubmit={submit}>
        <label>Which is a JS framework? (required)</label><br/>
        <select name="q1" required>
          <option value="">--choose--</option><option value="A">HTML</option><option value="B">React</option><option value="C">CSS</option>
        </select><br/><br/>
        <button type="submit">Submit</button>
      </form>
      <p>{msg}</p>
    </div>
  )
}