import React, { useState } from 'react';
import axios from 'axios';
export default function Login({ onLogin }){
  const [username, setUsername] = useState('student');
  const [password, setPassword] = useState('password');
  const [msg, setMsg] = useState('');

  async function submit(e){
    e.preventDefault();
    try{
      const res = await axios.post('http://localhost:4000/api/login', { username, password });
      onLogin(res.data.token);
      setMsg('Logged in');
    }catch(err){
      setMsg('Login failed');
    }
  }
  return (
    <div style={{border:'1px solid #ddd', padding:16, borderRadius:6}}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <div><input value={username} onChange={e=>setUsername(e.target.value)} /></div>
        <div style={{marginTop:8}}><input type="password" value={password} onChange={e=>setPassword(e.target.value)} /></div>
        <div style={{marginTop:8}}><button type="submit">Login</button></div>
      </form>
      <p>{msg}</p>
      <p>Demo: student / password</p>
    </div>
  )
}